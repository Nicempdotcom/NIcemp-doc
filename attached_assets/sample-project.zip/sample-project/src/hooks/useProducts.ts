export function useProducts() { return {}; }
